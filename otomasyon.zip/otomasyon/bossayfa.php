
  <!-- HEADER -->
     <?php require_once'header.php'; ?>
     <!-- /HEADER -->

    <!-- sidebar -->
    <?php require_once'sidebar.php'; ?>
    <!-- /sidebar -->


    <!-- partial -->
    <div class="container-fluid page-body-wrapper">

   

     <!-- partial -->
     <div class="main-panel">
      <div class="content-wrapper">

        <!-- Siyah alan başlangıç -->




        <!-- Siyah alan bitiş -->


      </div>

      <!-- footer -->
      <?php require_once'footer.php'; ?>
      <!-- /footer -->

